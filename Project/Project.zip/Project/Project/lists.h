#include<bits/stdc++.h>
using namespace std;
string category[5]= {"Flowering Plants",
                    "Fruit Plants",
                    "Indoor Plants",
                    "Vegetable Plants",
                    "Herbal Plants"};

string season[3]={"Summer",
                  "Rainy",
                  "Winter"};

int category_season[61][2]={{0,0},{1,1},{1,1},{1,1},{1,1},
                            {2,1},{2,1},{2,1},{2,1},
                            {3,1},{3,1},{3,1},{3,1},
                            {4,1},{4,1},{4,1},{4,1},
                            {5,1},{5,1},{5,1},{5,1},
                            {1,2},{1,2},{1,2},{1,2},
                            {2,2},{2,2},{2,2},{2,2},
                            {3,2},{3,2},{3,2},{3,2},
                            {4,2},{4,2},{4,2},{4,2},
                            {5,2},{5,2},{5,2},{5,2},
                            {1,3},{1,3},{1,3},{1,3},
                            {2,3},{2,3},{2,3},{2,3},
                            {3,3},{3,3},{3,3},{3,3},
                            {4,3},{4,3},{4,3},{4,3},
                            {5,3},{5,3},{5,3},{5,3}};

string plant[61]={" ","moss rose",
                 "golden trumpet",
                 "red frangipani",
                 "porcelainflower",
                 "mini craneflower",
                 "busy lizzie",
                 "cranberry hibiscus",
                 "malabar melastome",
                 "johnny jump up",
                 "garden cosmos",
                 "sunflower",
                 "marigold",
                 "mango",
                 "litchi",
                 "watermelon",
                 "longan",
                 "guava",
                 "rose Apple",
                 "water chestnut",
                 "sapodila",
                 "orange",
                 "pomelo",
                 "jujubi",
                 "strawberry",
                 "rubber Plant",
                 "aloe Vera",
                 "money Plant",
                 "peace Lily",
                 "rain lily",
                 "lucky Bamboo",
                 "antherium",
                 "golden Pothos",
                 "fairy Castle Cactus",
                 "ball Cactus",
                 "string of Pearls",
                 "mother of thousands",
                 "indian spinach",
                 "red amaranth",
                 "Kangkong",
                 "pumpkin",
                 "bottle Gourd",
                 "okra",
                 "cucumber",
                 "eggplant",
                 "cabbage",
                 "cauliflower",
                 "tomato",
                 "winter squash",
                 "curry Leaves",
                 "rosemary",
                 "mint",
                 "oregano",
                 "lemon Balm",
                 "brahmi",
                 "peppermint",
                 "kalmegh",
                 "turmeric",
                 "ashwagandha",
                 "lavender",
                 "coriander"};


string scientific_name[61]={" ","Portulaca grandiflora\n\n" , "Allamanda cathartica\n\n", "Plumeria rubra\n\n", "Hoya carnosa\n\n", "Strelitzia reginae\n\n", "Impatiens walleriana\n\n", "Hibiscus acetosella\n\n", "Melastoma malabathricum\n\n", "Viola tricolor\n\n", "Cosmos bipinnatus\n\n", "Helianthus annuus\n\n", "Tagetes erecta\n\n", "Mangifera indica\n\n", "Litchi chinensis\n\n", "Citrullus lanatus\n\n", "Dimocarpus longan\n\n", "Psidium guajava\n\n", "Syzygium jambos\n\n", "Eleocharis dulcis\n\n", "Manilkara zapota\n\n", "Citrus sinensis\n\n", "Citrus maxima\n\n", "Ziziphus jujuba\n\n", "Fragaria ananassa\n\n", "Ficus elastica\n\n", "Aloe barbadensis miller\n\n", "Epipremnum aureum\n\n", "Spathiphyllum spp\n\n", "Zephyranthes spp.\n\n", "Dracaena sanderiana\n\n", "Anthurium andraeanum\n\n", "Epipremnum aureum\n\n", "Acanthocereus tetragonus\n\n", "Parodia magnifica\n\n", "Curio rowleyanus\n\n", "Kalanchoe daigremontiana\n\n", "Basella alba\n\n", "Amaranthus cruentus\n\n", "Ipomoea aquatica\n\n", "Cucurbita pepo\n\n", "Lagenaria siceraria\n\n", "Abelmoschus esculentus\n\n", "Cucumis sativus\n\n", "Solanum melongena\n\n", "Brassica oleracea var. capitata\n\n", "Brassica oleracea var. botrytis\n\n", "Solanum lycopersicum\n\n", "Cucurbita maxima\n\n", "Murraya koenigii\n\n", "Salvia rosmarinus\n\n", "Mentha spp.\n\n", "Origanum vulgare\n\n", "Melissa officinalis\n\n", "Bacopa monnieri\n\n"," Mentha � piperita\n\n", "Andrographis paniculata\n\n", "Curcuma longa\n\n", "Withania somnifera\n\n", "Lavandula spp.\n\n", "Coriandrum sativum\n\n"
                            };

string family[61]={" ","Portulacaceae\n\n", "Apocynaceae\n\n", "Apocynaceae\n\n", "Apocynaceae\n\n",
        "Strelitziaceae\n\n", "Balsaminaceae\n\n", "Malvaceae\n\n", "Melastomataceae\n\n",
        "Violaceae\n\n", "Asteraceae\n\n", "Asteraceae\n\n", "Asteraceae\n\n",
        "Anacardiaceae\n\n", "Sapindaceae\n\n", "Cucurbitaceae\n\n", "Sapindaceae\n\n",
        "Myrtaceae\n\n", "Myrtaceae\n\n", "Lythraceae\n\n", "Sapotaceae\n\n",
        "Rutaceae\n\n", "Rutaceae\n\n", "Rhamnaceae\n\n", "Rosaceae\n\n",
        "Moraceae\n\n", "Asphodelaceae\n\n", "Araceae\n\n", "Araceae\n\n",
        "Amaryllidaceae\n\n", "Asparagaceae\n\n", "Araceae\n\n", "Araceae\n\n",
        "Cactaceae\n\n", "Cactaceae\n\n", "Asteraceae\n\n", "Crassulaceae\n\n",
        "Basellaceae\n\n", "Amaranthaceae\n\n", "Convolvulaceae\n\n", "Cucurbitaceae\n\n",
        "Cucurbitaceae\n\n", "Malvaceae\n\n", "Cucurbitaceae\n\n", "Solanaceae\n\n",
        "Brassicaceae\n\n", "Brassicaceae\n\n", "Solanaceae\n\n", "Cucurbitaceae\n\n",
        "Rutaceae\n\n", "Lamiaceae\n\n", "Lamiaceae\n\n", "Lamiaceae\n\n",
        "Lamiaceae\n\n", "Plantaginaceae\n\n", "Lamiaceae\n\n", "Acanthaceae\n\n",
        "Zingiberaceae\n\n", "Solanaceae\n\n", "Lamiaceae\n\n", "Apiaceae\n\n"};

string local_name[61]={" ",
                       "Time Fuul",
                        };

string cultivation_month[61]={" ",
                              "February to May",
                             };

string growing_conditions[61]={" ",
                               " ",
                              };

string soil_type[61]={" ",
                      "Prefers well-drained, sandy or loamy soil",
                     };

string water_requirement[61]={" ",
                              "Low to moderate watering",
                             };

string temperature[61]={" ",
                       "20�C to 30�C (68�F to 86�F)",
                        };

string diseases[61]={" ",
                       "\nRoot Rot: Often due to overwatering or poor drainage.\nPowdery Mildew: Fungal disease causing a white powdery coating on leaves.\nAphid Infestation: Small insects that feed on plant sap.",
                        };

string diseases_management[61]={" ",
                                "\nRoot Rot: Ensure proper drainage and avoid overwatering. Use fungicides if necessary.\nPowdery Mildew: Improve air circulation, reduce humidity, and apply fungicides.\nAphid Control: Use insecticidal soap or neem oil. Introduce natural predators like ladybugs.",
                               };


